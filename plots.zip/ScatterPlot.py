import pandas as pd
import matplotlib.pyplot as plt
import sys

df=pd.read_csv(sys.argv[1], header=None, names=['col1','col2'])

plt.scatter(df['col1'], df['col2'], color='#dd12dd',label="Crude Birth Rates in Rural and Urban areas")

plt.title('Scatter-Plot ')
plt.xlabel('Year')
plt.ylabel('Birth Rate')

plt.legend()
plt.show()
