import pandas as pd
import matplotlib.pyplot as plt
import sys

df=pd.read_csv(sys.argv[1], header=None, names=['col1'])

x = ['2007-08', '2008-09', '2009-10', '2010-11', '2011-12', '2012-13', '2013-14', '2014-15', '2015-16']

plt.bar(x, df['col1'], color='#ddbbaa', label='Revenue collection')

plt.title('Scientific & Technical Consultancy Services ')
plt.xlabel('Year')
plt.ylabel('Revenue(in Rs.Crores)')

plt.legend()

plt.show()
