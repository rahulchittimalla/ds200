import pandas as pd
import matplotlib.pyplot as plt
import sys

df=pd.read_csv(sys.argv[1], header=None, names=['col1','col2','col3','col4'])
plotMap=[]

plotMap.append(df['col3'].dropna().tolist())
plotMap.append(df['col4'].dropna().tolist())

plt. boxplot(plotMap)

plt.xticks([1,2], ["Rural", "Urban"])
plt.title('Crude Birth rates in Rural and Urban areas (1981-2012)')
plt.ylabel('Crude Birth Rate')

plt.legend()
plt.show()
